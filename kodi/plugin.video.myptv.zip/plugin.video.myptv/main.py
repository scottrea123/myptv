import sys
import json
import urllib.parse
import urllib.request

import xbmcplugin
import xbmcgui

ADDON_HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]

# ---------- CONFIG ----------
USERNAME = "6743"
PASSWORD = "4326"

CATEGORIES_URL = f"https://wavecanada.app/player_api.php?username={USERNAME}&password={PASSWORD}&action=get_live_categories"
STREAMS_URL = "https://wavecanada.app/player_api.php?username={username}&password={password}&action=get_live_streams&category_id={category_id}"
TS_URL = f"https://wavecanada.app/live/{USERNAME}/{PASSWORD}/{{stream_id}}.ts"

# ---------- HELPERS ----------
def get_json(url):
    req = urllib.request.Request(url, headers={"User-Agent": "Kodi"})
    with urllib.request.urlopen(req) as resp:
        return json.loads(resp.read().decode())

def build_url(query):
    return BASE_URL + '?' + urllib.parse.urlencode(query)

# ---------- CATEGORY LIST ----------
def list_categories():
    data = get_json(CATEGORIES_URL)

    for cat in data:
        name = cat["category_name"]
        cid = cat["category_id"]

        url = build_url({
            "action": "streams",
            "category_id": cid
        })

        li = xbmcgui.ListItem(label=name)
        xbmcplugin.addDirectoryItem(
            handle=ADDON_HANDLE,
            url=url,
            listitem=li,
            isFolder=True
        )

    xbmcplugin.endOfDirectory(ADDON_HANDLE)

# ---------- STREAM LIST ----------
def list_streams(category_id):
    url = STREAMS_URL.format(username=USERNAME, password=PASSWORD, category_id=category_id)
    data = get_json(url)

    for stream in data:
        name = stream["name"]
        sid = stream["stream_id"]

        url = build_url({
            "action": "play",
            "stream_id": sid
        })

        li = xbmcgui.ListItem(label=name)
        li.setProperty("IsPlayable", "true")

        xbmcplugin.addDirectoryItem(
            handle=ADDON_HANDLE,
            url=url,
            listitem=li,
            isFolder=False
        )

    xbmcplugin.endOfDirectory(ADDON_HANDLE)

# ---------- PLAY STREAM ----------
def play_stream(stream_id):
    url = TS_URL.format(stream_id=stream_id)

    li = xbmcgui.ListItem(path=url)
    xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, li)

# ---------- ROUTER ----------
def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))

    action = params.get("action")

    if action is None:
        list_categories()
    elif action == "streams":
        list_streams(params["category_id"])
    elif action == "play":
        play_stream(params["stream_id"])

router(sys.argv[2][1:])
